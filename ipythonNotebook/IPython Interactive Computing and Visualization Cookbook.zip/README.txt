The up-to-date version of the code can be found on the GitHub repository:
https://github.com/ipython-books/cookbook-code

It is highly recommended to use the online, updated version on GitHub rather
than the code in this folder. You will find all instructions to clone the
repository there.
